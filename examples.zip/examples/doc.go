// Package examples contains sample applications for trying out the concepts in OpenShift 3.
package examples
