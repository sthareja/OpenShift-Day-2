# OpenShift Container Storage Examples  [WIP]

OpenShift Applications/Containers/Pods have the ability to use Persistent Local and Distributed Storage, below are some examples that will explore some of these scenarios:

* [HostPath](./host-path-examples)
* [GlusterFS Storage Examples](./gluster-examples)
* TBD - Ceph
* TBD - Cinder
* 
