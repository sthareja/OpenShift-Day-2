Scripts to populate OpenShift
=============================



templates
users
projects
